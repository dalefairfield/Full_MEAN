var mongoose = require('mongoose');
var User = mongoose.model('User')
function UsersController(){
  this.register = function(req,res){
    console.log("we are inside our backend users controller")
    // console.log(req.body)
    // console.log("confirm password",req.body.confirmpassword)

    // if(req.body.password===req.body.confirmpassword){
      var user = new User(req.body)
      user.save(function(err, user){
        console.log("saved user, sending a json response", {err:err, user:user})
        res.json({err:err, user:user})
      })
  };
  this.login=function(res,req){
    console.log("we are inside our backend users controller")
    console.log("req.body login", req.body)
    var userlogin = new UserLogin(req.body)
    user.findOne({email:req.body.email}), function(err, userlogin){
      res.json({err:err, userlogin:userlogin})
    })
  }
}
module.exports = new UsersController();
