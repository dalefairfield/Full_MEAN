var mongoose = require('mongoose');
var UserSchema = new mongoose.Schema({
	firstname: {type:String, required: true, min:2},
	lastname: {type:String, required: true, min:3},
	email: {type:String, required: true, unique:true},
	password: {type:String, required: true, min:6},
	birthday: {type:Date, required: true}
},{timestamps:true})

mongoose.model('User', UserSchema); //For more information, research mongoose schemas
