app.factory('usersFactory', ['$http', function($http) {
  var welcome_message = "Welcome to the simple Mean project set up."
  function UsersFactory(){
  	console.log("welcome factory instantiated")
	  this.index = function(callback){
	    callback(welcome_message)
	  }
	  this.register = function(newUser, callback){
	  	console.log("inside factory register")
	  	console.log("factory newUser:", newUser)
	  	alert("entering backend console!")
	  	$http.post('/users', newUser).then(function(response_data){
	  		console.log("inside factory REGISTER http callback")
	  		console.log(response_data)
	  		callback(response_data)
	  	})
	  }
    this.login= function(logger, callback){
      console.log("inside factory login")
      console.log("factory logger", logger)
      alert("entering backend console!")
      $http.post('/users', logger).then(function(response_data){
        console.log("inside factory LOGIN http callback")
        console.log(response_data)
        callback(response_data)
	  	})
    }
  }
  return new UsersFactory();
}]);
