app.controller('registersController', ['usersFactory','$scope','$location','$routeParams', function(usersFactory, $scope, $location, $routeParams) {

  $scope.register = function(){
  	console.log("registerController register function")
  	console.log("$scope.user", $scope.user)
  	console.log("$scope.user.password", $scope.user.password)
  	usersFactory.register($scope.user, function(response_data){
  		console.log("back inside register controller create method")
  		$scope.newUser = response_data.data.user
      $location.url('new_page')
  	})
  }

  $scope.login = function(){
    console.log("registerController LOGIN function")
    console.log("$scope.user", $scope.userlogin)
    console.log("$scope.user.email", $scope.userlogin.email)
    console.log("$scope.user.password", $scope.userlogin.password)
    usersFactory.login($scope.userlogin, function(response_data){
      console.log("back inside register controller LOGIN method")
      $scope.logger = response_data.data.userlogin
      $location.url('new_page')
    })
  }
  // $scope.index();
}]);
